var indexSectionsWithContent =
{
  0: "abcefgijklmoprst",
  1: "gmt",
  2: "t",
  3: "g",
  4: "abcefgijlmoprt",
  5: "bfgklmrs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "모두",
  1: "클래스",
  2: "네임스페이스들",
  3: "파일들",
  4: "함수",
  5: "변수"
};

