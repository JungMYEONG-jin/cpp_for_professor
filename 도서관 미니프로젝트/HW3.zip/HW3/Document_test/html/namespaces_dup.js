var namespaces_dup =
[
    [ "testing", "namespacetesting.html", "namespacetesting" ]
];