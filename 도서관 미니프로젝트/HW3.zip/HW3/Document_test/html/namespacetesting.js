var namespacetesting =
[
    [ "internal", "namespacetesting_1_1internal.html", "namespacetesting_1_1internal" ]
];