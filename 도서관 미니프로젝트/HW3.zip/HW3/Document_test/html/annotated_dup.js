var annotated_dup =
[
    [ "testing", "namespacetesting.html", "namespacetesting" ],
    [ "Mock_Lib_Member_Delete", "class_mock___lib___member___delete.html", "class_mock___lib___member___delete" ],
    [ "Mock_Library_rent", "class_mock___library__rent.html", "class_mock___library__rent" ],
    [ "Mock_Library_Search", "class_mock___library___search.html", "class_mock___library___search" ],
    [ "Mock_Library_Search_Book", "class_mock___library___search___book.html", "class_mock___library___search___book" ],
    [ "Mock_Rent", "class_mock___rent.html", "class_mock___rent" ],
    [ "MockBook", "class_mock_book.html", "class_mock_book" ],
    [ "MockMbember", "class_mock_mbember.html", "class_mock_mbember" ],
    [ "Test_Mock_Book", "class_test___mock___book.html", "class_test___mock___book" ],
    [ "Test_Mock_Rent", "class_test___mock___rent.html", "class_test___mock___rent" ],
    [ "Test_MockMember", "class_test___mock_member.html", "class_test___mock_member" ]
];