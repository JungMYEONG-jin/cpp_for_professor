var class_test___mock_member =
[
    [ "Test_MockMember", "class_test___mock_member.html#a0c2e73eccf8853ab43c1c672cfc422f2", null ],
    [ "initName", "class_test___mock_member.html#ad1b4d19bdd4f2154c911278c01aea357", null ],
    [ "initPhone", "class_test___mock_member.html#a965c0af644b37d3394adec6eb3d6ae89", null ],
    [ "mem", "class_test___mock_member.html#aea23dd77b3c90eb67bf60ba03249d1d0", null ]
];