var class_test___mock___book =
[
    [ "Test_Mock_Book", "class_test___mock___book.html#aa0a35e0d2aeef93ab3d20ce94902daef", null ],
    [ "init_book_name", "class_test___mock___book.html#a616e09163e5a684b5b8386d6e85b5f37", null ],
    [ "init_id", "class_test___mock___book.html#a2bbf93b70b555c4886f4ccc2a8bb3d25", null ],
    [ "init_writer_name", "class_test___mock___book.html#ac4f0d296b019c3ef6ad2362d6f1d3021", null ],
    [ "book", "class_test___mock___book.html#add5de581a510e89fa86e899082d2193a", null ]
];