var searchData=
[
  ['member_86',['Member',['../class_member.html#a44241aa6aa9b792b550d9cc29e7ad050',1,'Member::Member()'],['../class_member.html#aa5ce691c4579012141844f574b90edb3',1,'Member::Member(string _phone, string _name)']]]
];
