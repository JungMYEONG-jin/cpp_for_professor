var searchData=
[
  ['name_119',['name',['../class_book.html#a9afedb80b692466dc2d91f109970a32c',1,'Book::name()'],['../class_member.html#a9777c104747d3ee2950bf755c296c022',1,'Member::name()']]],
  ['numofbook_120',['numOfBook',['../class_library.html#aa5162d02ed45df913afe15d38271d698',1,'Library']]]
];
