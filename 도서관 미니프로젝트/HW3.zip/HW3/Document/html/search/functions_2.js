var searchData=
[
  ['deletebook_74',['DeleteBook',['../class_library.html#a3fe1e6f3dc483813a301e29c11e91a66',1,'Library']]],
  ['deletemember_75',['DeleteMember',['../class_library.html#aaf70749238808bf5d64e14262162c943',1,'Library']]]
];
