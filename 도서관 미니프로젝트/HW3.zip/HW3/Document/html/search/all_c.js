var searchData=
[
  ['writer_53',['writer',['../class_book.html#ad0179d82b32e93f2373ccae5586e2527',1,'Book']]]
];
