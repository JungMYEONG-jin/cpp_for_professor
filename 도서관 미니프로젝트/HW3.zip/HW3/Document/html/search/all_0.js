var searchData=
[
  ['addbook_0',['AddBook',['../class_library.html#ae4a3d5f1db944151d0a4e986a814d436',1,'Library']]],
  ['addmember_1',['AddMember',['../class_library.html#ab59728150622abb8015ecdcabcad89d8',1,'Library']]]
];
