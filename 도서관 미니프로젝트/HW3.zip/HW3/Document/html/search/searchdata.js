var indexSectionsWithContent =
{
  0: "abdgilmnoprsw~",
  1: "blmr",
  2: "blmr",
  3: "abdgilmoprs~",
  4: "bdimnprw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "모두",
  1: "클래스",
  2: "파일들",
  3: "함수",
  4: "변수"
};

