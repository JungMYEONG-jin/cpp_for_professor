var searchData=
[
  ['book_73',['Book',['../class_book.html#a2eac9e235a08763158f78533f7a83e1f',1,'Book::Book()'],['../class_book.html#a28f97eb80466fd47629d57908b246ed8',1,'Book::Book(string _name, string _writer, unsigned int _id)']]]
];
