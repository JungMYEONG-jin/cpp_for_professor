var annotated_dup =
[
    [ "Book", "class_book.html", "class_book" ],
    [ "Library", "class_library.html", "class_library" ],
    [ "Member", "class_member.html", "class_member" ],
    [ "RentInfo", "class_rent_info.html", "class_rent_info" ]
];