var class_member =
[
    [ "Member", "class_member.html#a44241aa6aa9b792b550d9cc29e7ad050", null ],
    [ "Member", "class_member.html#aa5ce691c4579012141844f574b90edb3", null ],
    [ "~Member", "class_member.html#a9e993260f63c73a91f1cb9b55fcef903", null ],
    [ "getName", "class_member.html#a68edc5bc2fe65c1cf22b4faac10d09c0", null ],
    [ "getPhoneNumber", "class_member.html#a92d5ed1df79c60a0dead21204c80257d", null ],
    [ "operator==", "class_member.html#a136468cabf2d99c0d9108932fe78e7fa", null ],
    [ "setName", "class_member.html#a1956bb29ef7c9a40d513097ea2c428db", null ],
    [ "setPhone", "class_member.html#a8bf6d074e33496a92efcb94a822c1f48", null ],
    [ "name", "class_member.html#a9777c104747d3ee2950bf755c296c022", null ],
    [ "phone", "class_member.html#a66109d32a419860093b38460445a5dc0", null ]
];