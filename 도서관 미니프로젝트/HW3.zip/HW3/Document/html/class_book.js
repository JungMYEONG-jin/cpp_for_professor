var class_book =
[
    [ "Book", "class_book.html#a2eac9e235a08763158f78533f7a83e1f", null ],
    [ "Book", "class_book.html#a28f97eb80466fd47629d57908b246ed8", null ],
    [ "~Book", "class_book.html#a990cf38dc698eff780291587b56c8011", null ],
    [ "get_book_name", "class_book.html#ab0da8d455afd2b1c55f1fb52f9bcd0d8", null ],
    [ "get_id", "class_book.html#a874a8975f55e6ce474f6e1e50c7174f4", null ],
    [ "get_writer_name", "class_book.html#ae2ec5f1b650b825ef37b7ade39f94136", null ],
    [ "operator<", "class_book.html#adb3244b3ea0df4553b09ee32c53fe8b9", null ],
    [ "operator==", "class_book.html#ad5dab4f3cd3f9e1671bf7bc9ede3e09c", null ],
    [ "set_id", "class_book.html#aacf571b6b69193d7d360f87d94919a95", null ],
    [ "set_name", "class_book.html#ade04c465c649c21ed9aaa1a310a05b23", null ],
    [ "set_writer", "class_book.html#a2fb30a8566f497a41da4ee7f4b120fb2", null ],
    [ "id", "class_book.html#a5aa98ca102428cd941d8813e0df8e8c8", null ],
    [ "name", "class_book.html#a9afedb80b692466dc2d91f109970a32c", null ],
    [ "writer", "class_book.html#ad0179d82b32e93f2373ccae5586e2527", null ]
];